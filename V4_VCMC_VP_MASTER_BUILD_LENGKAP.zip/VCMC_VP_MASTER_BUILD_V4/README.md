# VCMC-VP — MASTER BUILD / RENDER READY

Status: BUILD ARTIFACT — NOT YET PUBLIC / NOT PRODUCTION.

This package is the consolidated executable baseline for the VCMC Platform. It is intentionally a real runnable machine, not a prose specification.

## Included operational components
- HTTPS-ready HTTP service boundary
- Login boundary for `vcmcpusat@gmail.com` (password supplied only as deployment secret)
- Workspace / Sovereign Console
- Identity + role boundary
- Active rule registry: VCMC-ALLOC-001 v1.0.0
- Calculation and allocation engine
- Case and activity records
- Destinations
- Evidence hashing and pending verification state
- Ledger
- Reconciliation records
- Audit trail
- Notifications
- Payment/provider boundary with simulation only
- SQLite persistence
- Health endpoint
- Docker/Render deployment configuration
- No real-money movement or provider credentials

## Important truth boundary
This artifact does NOT claim that a public HTTPS deployment, real PJP execution, production security review, or production pilot has already occurred. Those require external deployment and verification.

## Local run
Set `VCMC_ADMIN_PASSWORD`, then:
`python app/server.py`
Open `http://127.0.0.1:8765`

## Render
Create a Web Service from this repository/package using the included Dockerfile or render.yaml. Set the secret `VCMC_ADMIN_PASSWORD` in Render Environment Variables.

## Partner / Room access layer
- Organization registry and membership boundary
- Candidate partner onboarding: CANDIDATE → VERIFIED → PILOT_ACTIVE → COMPLETED/SUSPENDED/ARCHIVED
- Partner workspace per organization
- Sovereign workspace for VCMC Central
- Role/organization boundary is separate from payment execution
- Candidate is not Pilot; access is not authority
- Reconciliation completion endpoint records case completion and audit trail

## V2/V3 hardening added in current working build
- Explicit case state-transition guard including UNKNOWN/HOLD; UNKNOWN is not FAILED.
- Evidence verification endpoint.
- Provider registry and payment-instruction boundary; execution remains disabled.
- Idempotency table reserved for request replay protection.
- Summary/readiness reporting endpoints.
- Real-money execution remains OFF until external PJP/provider, security, deployment, and reconciliation evidence are verified.


## V4 gap-check hardening
- Security headers and request-size limit.
- Session TTL configurable; bearer tokens remain hashed at rest.
- Security event log for failed logins.
- Role authorization gates for sensitive partner/provider/evidence/payment-instruction operations.
- Idempotency-Key support for case creation, partner registration, simulated payments, and payment instructions.
- SQLite online backup endpoint with SHA-256 backup record.
- Monitoring metrics endpoint.
- Reporting summary endpoint.
- API capability/version endpoint.
- Provider registration boundary; real execution remains disabled.
- HTTPS readiness detects forwarded HTTPS but does not claim external deployment.
- Real-money gate remains OFF by default and requires external PJP/provider verification.

## V4 VERIFIED BUILD STATUS
- Local executable test suite: PASS (4 test files).
- Security/authz/idempotency/backup/monitoring/reporting/provider-gate test: PASS.
- Backup artifact generation: verified with SHA-256 record.
- Real-money execution: OFF.
- Public HTTPS: NOT YET VERIFIED (requires external deployment).
- Real PJP/Xendit execution: NOT YET VERIFIED (requires external credentials/contract/configuration and controlled test).
