# VCMC-VP — Backup / Recovery Procedure

1. Stop the VCMC-VP process.
2. Keep the original database file untouched.
3. Select a verified backup whose SHA-256 matches the recorded value.
4. Copy the verified backup to the configured `VCMC_DB` path.
5. Start VCMC-VP and run the health, case, ledger, audit, and reconciliation checks.
6. Record the recovery event in the operational evidence/audit record.

The application does not automatically overwrite a live production database from a backup. Recovery is a controlled operational action.
