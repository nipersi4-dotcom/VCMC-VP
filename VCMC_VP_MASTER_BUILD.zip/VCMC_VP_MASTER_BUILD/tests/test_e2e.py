import os,sys,tempfile,threading,urllib.request,json,time,shutil
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'..','app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'; os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_e2e.db'); os.environ['VCMC_BACKUP_DIR']=os.path.join(tempfile.gettempdir(),'vcmc_vp_e2e_backups'); os.environ['VCMC_REAL_MONEY_ENABLED']='false'
try: os.remove(os.environ['VCMC_DB'])
except FileNotFoundError: pass
shutil.rmtree(os.environ['VCMC_BACKUP_DIR'],ignore_errors=True)
import server
server.DB=os.environ['VCMC_DB']; server.BACKUP_DIR=os.environ['VCMC_BACKUP_DIR']; server.ADMIN_PASSWORD='TEST-PASSWORD'; server.ADMIN_EMAIL='vcmcpusat@gmail.com'; server.REAL_MONEY_ENABLED=False; server.init()
from http.server import ThreadingHTTPServer
srv=ThreadingHTTPServer(('127.0.0.1',18766),server.H); threading.Thread(target=srv.serve_forever,daemon=True).start(); time.sleep(.1)
def req(path,method='GET',body=None,token=None,headers=None):
 h=headers or {}; data=None
 if body is not None: h['Content-Type']='application/json'; data=json.dumps(body).encode()
 if token: h['Authorization']='Bearer '+token
 r=urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18766'+path,data=data,method=method,headers=h)); return r.status,json.loads(r.read().decode())
s,d=req('/api/login','POST',{'email':'vcmcpusat@gmail.com','password':'TEST-PASSWORD'}); assert s==200; tok=d['token']
s,c=req('/api/cases','POST',{'gross':100000000},tok,); assert s==201; cid=c['case_id']; assert c['calculation']['balance']==0
s,l=req('/api/ledger?case_id='+cid,token=tok); assert s==200 and round(sum(x['amount'] for x in l),2)==100000000 and any(x['type']=='MITRA' for x in l)
for st in ['VALIDATING','VERIFIED','AUTHORIZED','PROCESSING','EXECUTED','EVIDENCE_PENDING','RECONCILIATION_PENDING']:
 s,_=req('/api/cases/transition','POST',{'case_id':cid,'status':st},tok); assert s==200
s,e=req('/api/evidence','POST',{'case_id':cid,'kind':'PILOT_EVIDENCE','content':'e2e'},tok); assert s==201
s,v=req('/api/evidence/verify','POST',{'evidence_id':e['evidence_id'],'status':'VERIFIED'},tok); assert s==200
s,r=req('/api/reconciliation/complete','POST',{'case_id':cid},tok); assert s==200 and r['case_status']=='RECONCILED'
s,_=req('/api/cases/transition','POST',{'case_id':cid,'status':'COMPLETED'},tok); assert s==200
s,cases=req('/api/cases',token=tok); assert any(x['id']==cid and x['status']=='COMPLETED' for x in cases)
s,a=req('/api/allocations',token=tok); assert s==200 and any(x['case_id']==cid for x in a)
s,n=req('/api/notifications','POST',{'kind':'E2E','message':'VCMC E2E complete'},tok); assert s==201
srv.shutdown(); print('VCMC-VP FULL END-TO-END TEST: PASS')
