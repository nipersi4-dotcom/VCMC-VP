import os, sys, tempfile, sqlite3, hashlib, shutil
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'
os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_recovery_source.db')
os.environ['VCMC_BACKUP_DIR']=os.path.join(tempfile.gettempdir(),'vcmc_vp_recovery_backups')
for p in [os.environ['VCMC_DB']]:
    try: os.remove(p)
    except FileNotFoundError: pass
shutil.rmtree(os.environ['VCMC_BACKUP_DIR'], ignore_errors=True)
import server
server.init()
c=server.db(); c.execute("INSERT INTO cases VALUES(?,?,?,?,?)",('CASE-RECOVERY','CREATED',server.now(),'REQ-REC','test')); c.commit(); c.close()
b=server.backup_database()
assert os.path.exists(b['path'])
assert hashlib.sha256(open(b['path'],'rb').read()).hexdigest()==b['sha256']
check=sqlite3.connect(b['path']); n=check.execute("SELECT COUNT(*) FROM cases WHERE id='CASE-RECOVERY'").fetchone()[0]; check.close()
assert n==1
print('BACKUP / RECOVERY ARTIFACT TEST: PASS')
