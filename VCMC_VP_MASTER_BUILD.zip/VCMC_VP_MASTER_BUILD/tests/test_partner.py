import os,sys,tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'
os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_partner_test.db')
try: os.remove(os.environ['VCMC_DB'])
except FileNotFoundError: pass
import server
server.init()
c=server.db()
assert c.execute("SELECT status FROM partner_profiles").fetchone() is None
c.close()
print('PARTNER/ROOM FOUNDATION TEST: PASS')
