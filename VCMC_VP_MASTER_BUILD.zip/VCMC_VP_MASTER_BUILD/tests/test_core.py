import os, sys, tempfile, json, threading, urllib.request
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'
os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_test.db')
try: os.remove(os.environ['VCMC_DB'])
except FileNotFoundError: pass
import server
server.init()
assert server.calculate(100_000_000)['balance'] == 0
assert server.calculate(100_000_000)['zakat'] == 2_500_000
assert server.calculate(100_000_000)['mitra'] == 39_000_000
assert server.calculate(100_000_000)['pusat'] == 39_000_000
assert server.calculate(100_000_000)['amal'] == 19_500_000
assert server.calculate(100_000_000)['ip'] == 15_600_000
assert server.calculate(100_000_000)['development'] == 15_600_000
assert server.calculate(100_000_000)['reserve'] == 7_800_000
print('GOLDEN ALLOCATION TEST: PASS')
print('RULE:', server.RULE_ID, server.RULE_VERSION)
