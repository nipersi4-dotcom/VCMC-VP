import os, sys, tempfile, threading, urllib.request, urllib.error, json, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'
os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_v4_test.db')
os.environ['VCMC_BACKUP_DIR']=os.path.join(tempfile.gettempdir(),'vcmc_vp_v4_backups')
os.environ['VCMC_REAL_MONEY_ENABLED']='false'
try: os.remove(os.environ['VCMC_DB'])
except FileNotFoundError: pass
import shutil
shutil.rmtree(os.environ['VCMC_BACKUP_DIR'], ignore_errors=True)
import server
server.DB=os.environ['VCMC_DB']; server.BACKUP_DIR=os.environ['VCMC_BACKUP_DIR']; server.ADMIN_PASSWORD='TEST-PASSWORD'; server.ADMIN_EMAIL='vcmcpusat@gmail.com'; server.REAL_MONEY_ENABLED=False
server.init()
from http.server import ThreadingHTTPServer
srv=ThreadingHTTPServer(('127.0.0.1', 18765), server.H)
t=threading.Thread(target=srv.serve_forever, daemon=True); t.start(); time.sleep(.1)

def req(path, method='GET', body=None, token=None, headers=None):
    h=headers or {}
    if body is not None: h['Content-Type']='application/json'; data=json.dumps(body).encode()
    else: data=None
    if token: h['Authorization']='Bearer '+token
    r=urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18765'+path,data=data,method=method,headers=h))
    return r.status, json.loads(r.read().decode()), dict(r.headers)

# login + security headers
status, data, headers=req('/api/login','POST',{'email':'vcmcpusat@gmail.com','password':'TEST-PASSWORD'})
assert status==200 and data['user']['email']=='vcmcpusat@gmail.com'
assert headers['X-Content-Type-Options']=='nosniff'
token=data['token']

# create case with idempotency, replay must not create another case
key='CASE-IDE-001'
s1,d1,_=req('/api/cases','POST',{'gross':100_000_000},token,{'Idempotency-Key':key})
s2,d2,_=req('/api/cases','POST',{'gross':100_000_000},token,{'Idempotency-Key':key})
assert s1==201 and s2==200 and d1['case_id']==d2['case_id']
c=server.db(); assert c.execute('SELECT COUNT(*) n FROM cases').fetchone()['n']==1; c.close()

# backup + hash record
sb,b,_=req('/api/backups/create','POST',{},token)
assert sb==201 and b['status']=='CREATED' and len(b['sha256'])==64 and os.path.exists(b['path'])

# monitoring/reporting/api
assert req('/api/metrics',token=token)[0]==200
summary=req('/api/reports/summary',token=token)[1]
assert summary['cases']==1 and summary['real_money_execution_enabled'] is False
api=req('/api/api',token=token)[1]
assert api['version']=='v1' and 'Idempotency-Key' in api['idempotency']

# provider registration remains non-executing
sp,p,_=req('/api/providers/register','POST',{'name':'Test PJP','kind':'PJP','capabilities':'payment_status,evidence_reference'},token)
assert sp==201 and p['execution_enabled'] is False

# real-money gate stays off
r=req('/api/system/readiness',token=token)[1]
assert r['real_money_enabled'] is False and r['real_pjp_execution_verified'] is False

srv.shutdown(); print('V4 SECURITY / AUTHZ / IDEMPOTENCY / BACKUP / MONITORING / REPORTING / PROVIDER GATE TEST: PASS')
