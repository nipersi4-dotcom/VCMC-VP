import os,sys,tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'app'))
os.environ['VCMC_ADMIN_PASSWORD']='TEST-PASSWORD'
os.environ['VCMC_DB']=os.path.join(tempfile.gettempdir(),'vcmc_vp_gap_test.db')
try: os.remove(os.environ['VCMC_DB'])
except FileNotFoundError: pass
import server
server.init()
assert server.ALLOWED_TRANSITIONS['PROCESSING']=={'EXECUTED','UNKNOWN','FAILED'}
assert server.ALLOWED_TRANSITIONS['UNKNOWN']=={'HOLD','FAILED','EXECUTED','CANCELLED'}
assert server.calculate(100_000_000)['balance']==0
c=server.db(); assert c.execute("SELECT id FROM providers WHERE id='PJP-SIM-001'").fetchone(); c.close()
print('STATE / PROVIDER / READINESS GAP TEST: PASS')
