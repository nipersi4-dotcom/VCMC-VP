# VCMC-VP — V4 COMPLETE BUILD

Status: BUILD VERIFIED / REAL-MONEY OFF

VCMC-VP is the operational platform layer for VCMC. This build implements the core machine boundary for identity, authorization, organization/partner rooms, cases, activities, active rule, calculation, allocation, destinations, ledger, payment boundary, evidence, verification, reconciliation, state machine, notifications, provider registry, security, backup/recovery, monitoring, reporting, API capability, deployment readiness, and tests.

## Locked allocation rule
- Zakat: 2.5% first
- Remaining 97.5%: 40% Mitra/Pelaksana, 40% Pusat VCMC/Pengembangan, 20% Amal & Kemanusiaan
- Pusat: 40% IP, 40% Development, 20% Reserve
- Rule ID: VCMC-ALLOC-001
- Version: 1.0.0

## Payment boundary
VCMC-VP calculates, allocates, validates destinations, creates payment instructions, records provider references, evidence and reconciliation. It does not claim to be a bank/PJP and real-money execution is disabled by default.

## Verification commands
Run each executable test script:

```bash
python tests/test_core.py
python tests/test_gap.py
python tests/test_partner.py
python tests/test_recovery.py
python tests/test_v4.py
python tests/test_e2e.py
```

Expected final lines:
- GOLDEN ALLOCATION TEST: PASS
- STATE / PROVIDER / READINESS GAP TEST: PASS
- PARTNER/ROOM FOUNDATION TEST: PASS
- BACKUP / RECOVERY ARTIFACT TEST: PASS
- V4 SECURITY / AUTHZ / IDEMPOTENCY / BACKUP / MONITORING / REPORTING / PROVIDER GATE TEST: PASS
- VCMC-VP FULL END-TO-END TEST: PASS

## Production boundary
This build is not a claim of live PJP/bank execution, production HTTPS, regulatory approval, or production operational approval. Those require real deployment, provider/PJP integration, security review, legal/compliance review, evidence and reconciliation.
